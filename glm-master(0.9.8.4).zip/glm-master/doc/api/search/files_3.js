var searchData=
[
  ['closest_5fpoint_2ehpp',['closest_point.hpp',['../a00010.html',1,'']]],
  ['color_5fencoding_2ehpp',['color_encoding.hpp',['../a00011.html',1,'']]],
  ['color_5fspace_5fycocg_2ehpp',['color_space_YCoCg.hpp',['../a00014.html',1,'']]],
  ['common_2ehpp',['common.hpp',['../a00015.html',1,'']]],
  ['compatibility_2ehpp',['compatibility.hpp',['../a00017.html',1,'']]],
  ['component_5fwise_2ehpp',['component_wise.hpp',['../a00018.html',1,'']]],
  ['constants_2ehpp',['constants.hpp',['../a00019.html',1,'']]]
];
